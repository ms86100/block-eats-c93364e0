import { useEffect, useState, useCallback, useContext, useRef } from 'react';
import { Capacitor } from '@capacitor/core';
import { supabase } from '@/integrations/supabase/client';
import { IdentityContext } from '@/contexts/auth/contexts';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { hapticNotification } from '@/lib/haptics';
import { getPushStage, setPushStage } from '@/lib/pushPermissionStage';

type RegistrationState = 'idle' | 'registering' | 'registered' | 'failed';

const MAX_RETRIES = 3;
const WATCHDOG_TIMEOUT_MS = 20000;

function isValidFcmToken(token: string, platform: string): boolean {
  if (platform === 'ios' && /^[A-Fa-f0-9]{64}$/.test(token)) {
    return false;
  }
  return token.length > 20;
}

async function getPushNotificationsPlugin() {
  try {
    const { PushNotifications } = await import('@capacitor/push-notifications');
    return PushNotifications;
  } catch (e) {
    console.warn('[Push] @capacitor/push-notifications not available:', e);
    return null;
  }
}

async function getFcmPlugin() {
  try {
    const { FCM } = await import('@capacitor-community/fcm');
    return FCM;
  } catch (e) {
    console.warn('[Push] @capacitor-community/fcm not available:', e);
    return null;
  }
}

let activeInstanceId = 0;

export function usePushNotificationsInternal() {
  const [token, setToken] = useState<string | null>(null);
  const [permissionStatus, setPermissionStatus] = useState<'granted' | 'denied' | 'prompt'>('prompt');
  const identity = useContext(IdentityContext);
  const user = identity?.user ?? null;
  const navigate = useNavigate();

  console.log('[Push][INIT] usePushNotifications render — platform:', Capacitor.getPlatform(), 'isNative:', Capacitor.isNativePlatform(), 'userId:', user?.id ?? 'null');

  const userRef = useRef(user);
  userRef.current = user;

  const registrationStateRef = useRef<RegistrationState>('idle');
  const retryCountRef = useRef(0);
  const watchdogTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastErrorRef = useRef<unknown>(null);
  const tokenRef = useRef<string | null>(null);
  const listenersReadyRef = useRef<Promise<void> | null>(null);
  const listenersReadyResolveRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    tokenRef.current = token;
  }, [token]);

  const clearWatchdog = useCallback(() => {
    if (watchdogTimerRef.current !== null) {
      clearTimeout(watchdogTimerRef.current);
      watchdogTimerRef.current = null;
    }
  }, []);

  const permissionStatusRef = useRef(permissionStatus);
  permissionStatusRef.current = permissionStatus;

  const emitDiagnostic = useCallback(() => {
    console.error('[Push][DIAG] Registration failed after retries', {
      userId: userRef.current?.id ?? 'unknown',
      platform: Capacitor.getPlatform(),
      permissionStatus: permissionStatusRef.current,
      retriesAttempted: retryCountRef.current,
      lastError: lastErrorRef.current,
      timestamp: new Date().toISOString(),
    });
  }, []);

  const markFailed = useCallback(() => {
    registrationStateRef.current = 'failed';
    clearWatchdog();
    emitDiagnostic();
  }, [clearWatchdog, emitDiagnostic]);

  const saveTokenToDatabase = useCallback(async (pushToken: string) => {
    const currentUser = userRef.current;
    console.log('[Push] saveTokenToDatabase called, user:', currentUser?.id ?? 'null', 'token:', pushToken.substring(0, 20) + '…');

    if (!currentUser) {
      console.warn('[Push] No user at token-save time — will retry when user is ready');
      return false;
    }

    const platform = Capacitor.getPlatform() as 'ios' | 'android' | 'web';

    try {
      const { error } = await supabase
        .from('device_tokens')
        .upsert(
          {
            user_id: currentUser.id,
            token: pushToken,
            platform,
            updated_at: new Date().toISOString(),
          },
          { onConflict: 'user_id,token' }
        );

      if (error) {
        console.error('[Push] Token upsert FAILED:', error.message, error.code, error.details);
        console.log('[Push] Attempting fallback INSERT…');
        const { error: insertErr } = await supabase
          .from('device_tokens')
          .insert({
            user_id: currentUser.id,
            token: pushToken,
            platform,
            updated_at: new Date().toISOString(),
          });
        if (insertErr) {
          if (insertErr.code === '23505') {
            console.log('[Push] Token already exists (unique constraint) — OK');
            return true;
          }
          console.error('[Push] Fallback INSERT also failed:', insertErr.message, insertErr.code);
          return false;
        }
        console.log('[Push] Token saved via fallback INSERT');
        return true;
      }
      console.log('[Push] Token saved successfully via upsert');
      return true;
    } catch (err) {
      console.error('[Push] Token save exception:', err);
      return false;
    }
  }, []);

  const userIdForCleanupRef = useRef<string | null>(null);
  useEffect(() => {
    if (user?.id) userIdForCleanupRef.current = user.id;
  }, [user?.id]);

  const removeTokenFromDatabase = useCallback(async () => {
    const uid = userIdForCleanupRef.current;
    if (!uid) return;

    try {
      const { error } = await supabase
        .from('device_tokens')
        .delete()
        .eq('user_id', uid);

      if (error) {
        console.error('[Push] Error removing push tokens:', error);
      } else {
        console.log('[Push] All tokens removed for user:', uid);
      }
    } catch (err) {
      console.error('[Push] Failed to remove push tokens:', err);
    }
  }, []);

  const handleValidToken = useCallback(async (tokenValue: string) => {
    clearWatchdog();
    registrationStateRef.current = 'registered';
    retryCountRef.current = 0;

    setToken(tokenValue);
    tokenRef.current = tokenValue;

    const saved = await saveTokenToDatabase(tokenValue);
    if (!saved) {
      console.log('[Push] Token save deferred — will retry when user becomes available');
    }
  }, [clearWatchdog, saveTokenToDatabase]);

  const tryFcmTokenDirectly = useCallback(async (): Promise<boolean> => {
    const platform = Capacitor.getPlatform();
    if (platform !== 'ios') return false;

    console.log('[Push][iOS] Attempting direct FCM.getToken() as fallback…');
    try {
      const fcm = await getFcmPlugin();
      if (!fcm) {
        console.error('[Push][iOS] FCM plugin not available for direct token fetch');
        return false;
      }

      const fcmResult = await fcm.getToken();
      const fcmToken = fcmResult?.token;
      if (!fcmToken || typeof fcmToken !== 'string') {
        console.error('[Push][iOS] FCM.getToken() returned invalid result:', fcmResult);
        return false;
      }

      console.log('[Push][iOS] Direct FCM token:', fcmToken.substring(0, 20) + '…', 'length:', fcmToken.length);

      if (!isValidFcmToken(fcmToken, 'ios')) {
        console.warn('[Push][iOS] Direct FCM token failed validation');
        return false;
      }

      await handleValidToken(fcmToken);
      return true;
    } catch (err) {
      console.error('[Push][iOS] Direct FCM.getToken() failed:', err);
      return false;
    }
  }, [handleValidToken]);

  const attemptRegistration = useCallback(async () => {
    const state = registrationStateRef.current;

    if (state === 'registered') {
      console.log('[Push] attemptRegistration skipped — already registered');
      return;
    }
    if (state === 'registering') {
      console.log('[Push] attemptRegistration skipped — already in progress');
      return;
    }

    registrationStateRef.current = 'registering';
    const attempt = retryCountRef.current + 1;
    const platform = Capacitor.getPlatform();
    console.log(`[Push] ▶ attemptRegistration — attempt ${attempt}/${MAX_RETRIES}, platform: ${platform}`);

    if (!Capacitor.isNativePlatform()) {
      console.log('[Push] Skipping — not a native platform');
      registrationStateRef.current = 'idle';
      return;
    }

    if (listenersReadyRef.current) {
      console.log('[Push] Waiting for listeners to be ready…');
      try {
        await Promise.race([
          listenersReadyRef.current,
          new Promise<void>((_, reject) => setTimeout(() => reject(new Error('Listener wait timeout')), 5000)),
        ]);
        console.log('[Push] Listeners confirmed ready');
      } catch (err) {
        console.warn('[Push] Listener wait timed out — proceeding anyway:', err);
      }
    }

    const PN = await getPushNotificationsPlugin();
    if (!PN) { markFailed(); return; }

    try {
      let permStatus = await PN.checkPermissions();
      console.log(`[Push][${platform}] ▶ checkPermissions:`, permStatus.receive);

      if (permStatus.receive === 'prompt') {
        console.log(`[Push][${platform}] ▶ Calling requestPermissions() NOW — iOS system dialog should appear`);
        permStatus = await PN.requestPermissions();
        console.log(`[Push][${platform}] ▶ requestPermissions result:`, permStatus.receive);
      }

      if (permStatus.receive !== 'granted') {
        const isDenied = permStatus.receive === 'denied';
        setPermissionStatus(isDenied ? 'denied' : 'prompt');
        registrationStateRef.current = 'idle';
        console.log(`[Push][${platform}] Permission not granted (${permStatus.receive}) — staying idle`);

        if (!isDenied) {
          console.error(`[Push][${platform}] ✗✗✗ CRITICAL: Permission still "${permStatus.receive}" after requestPermissions() — OS prompt may have been suppressed`);
        }
        return;
      }

      setPermissionStatus('granted');
      clearWatchdog();

      console.log(`[Push][${platform}] ▶ Calling PushNotifications.register()…`);
      await PN.register();
      console.log(`[Push][${platform}] ✓ register() completed — starting watchdog (${WATCHDOG_TIMEOUT_MS}ms)`);

      watchdogTimerRef.current = setTimeout(async () => {
        watchdogTimerRef.current = null;
        if (registrationStateRef.current === 'registered') return;

        console.warn(`[Push][${platform}] Watchdog expired — no token received via listener`);

        if (platform === 'ios') {
          console.log('[Push][iOS] Watchdog: trying direct FCM.getToken() fallback…');
          const got = await tryFcmTokenDirectly();
          if (got) {
            console.log('[Push][iOS] ✓ Watchdog fallback succeeded via direct FCM.getToken()');
            return;
          }
          console.warn('[Push][iOS] Watchdog fallback also failed');
        }

        retryCountRef.current += 1;
        console.warn(`[Push][${platform}] Retry ${retryCountRef.current}/${MAX_RETRIES}`);

        if (retryCountRef.current >= MAX_RETRIES) {
          markFailed();
        } else {
          registrationStateRef.current = 'idle';
          attemptRegistration();
        }
      }, WATCHDOG_TIMEOUT_MS);
    } catch (err) {
      console.error(`[Push][${platform}] Registration error:`, err);
      lastErrorRef.current = err;
      markFailed();
    }
  }, [clearWatchdog, markFailed, tryFcmTokenDirectly]);

  const handleForegroundNotification = useCallback((title: string, body: string, data?: Record<string, string>) => {
    console.log('[Push] Foreground notification:', title, body);
    hapticNotification('warning');

    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      for (let i = 0; i < 3; i++) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.value = i % 2 === 0 ? 880 : 660;
        osc.type = 'square';
        const start = ctx.currentTime + i * 0.2;
        gain.gain.setValueAtTime(0.25, start);
        gain.gain.exponentialRampToValueAtTime(0.01, start + 0.18);
        osc.start(start);
        osc.stop(start + 0.2);
      }
      setTimeout(() => ctx.close().catch(() => {}), 1000);
    } catch (e) {
      console.warn('[Push] Sound failed:', e);
    }

    toast(title || 'New Notification', {
      description: body || '',
      duration: 10000,
      action: data?.orderId
        ? { label: 'View', onClick: () => navigate(`/orders/${data.orderId}`) }
        : undefined,
    });
  }, [navigate]);

  const handleNotificationAction = useCallback((data?: Record<string, string>) => {
    if (data?.path || data?.reference_path) {
      navigate(data.path || data.reference_path!);
    } else if (data?.orderId) {
      navigate(`/orders/${data.orderId}`);
    } else if (data?.type === 'chat' && data?.orderId) {
      navigate(`/orders/${data.orderId}`);
    } else if (data?.type === 'order') {
      navigate('/orders');
    } else if (data?.type === 'visitor') {
      navigate('/visitor-management');
    } else if (data?.type === 'dispute') {
      navigate('/disputes');
    } else if (data?.type === 'maintenance') {
      navigate('/maintenance');
    } else if (data?.type === 'bulletin' || data?.type === 'notice') {
      navigate('/bulletin');
    } else {
      navigate('/notifications');
    }
  }, [navigate]);

  useEffect(() => {
    const myId = ++activeInstanceId;
    if (myId !== activeInstanceId) {
      console.warn('[Push] Duplicate instance detected — skipping effects');
      return;
    }
    console.log('[Push] Effect owner instance:', myId);

    if (!Capacitor.isNativePlatform()) return;

    const platform = Capacitor.getPlatform();
    const cleanups: (() => void)[] = [];

    let resolveListenersReady: () => void;
    listenersReadyRef.current = new Promise<void>((resolve) => {
      resolveListenersReady = resolve;
      listenersReadyResolveRef.current = resolve;
    });

    (async () => {
      const PN = await getPushNotificationsPlugin();
      if (!PN) {
        resolveListenersReady!();
        return;
      }

      const registrationListener = PN.addListener('registration', async (registrationToken) => {
        try {
          const rawToken = registrationToken?.value;
          if (!rawToken || typeof rawToken !== 'string' || rawToken.length === 0) {
            console.error(`[Push][${platform}] registration event — invalid token:`, registrationToken);
            return;
          }

          console.log(`[Push][${platform}] registration event — raw token:`, rawToken.substring(0, 20) + '…', 'length:', rawToken.length);

          if (platform === 'ios') {
            console.log('[Push][iOS] APNs token received — converting to FCM token via FCM.getToken()…');

            let fcmToken: string | null = null;
            for (let fcmAttempt = 0; fcmAttempt < 3; fcmAttempt++) {
              try {
                const fcm = await getFcmPlugin();
                if (!fcm) {
                  console.error('[Push][iOS] @capacitor-community/fcm not available — cannot convert token');
                  markFailed();
                  return;
                }
                const fcmResult = await fcm.getToken();
                fcmToken = fcmResult?.token ?? null;

                if (fcmToken && typeof fcmToken === 'string' && isValidFcmToken(fcmToken, 'ios')) {
                  break;
                }

                console.warn(`[Push][iOS] FCM.getToken() attempt ${fcmAttempt + 1}/3 — invalid token, retrying in ${(fcmAttempt + 1)}s…`);
                fcmToken = null;
                await new Promise(r => setTimeout(r, 1000 * (fcmAttempt + 1)));
              } catch (fcmErr) {
                console.error(`[Push][iOS] FCM.getToken() attempt ${fcmAttempt + 1}/3 exception:`, fcmErr);
                if (fcmAttempt < 2) {
                  await new Promise(r => setTimeout(r, 1000 * (fcmAttempt + 1)));
                }
              }
            }

            if (!fcmToken) {
              console.error('[Push][iOS] All FCM.getToken() attempts failed — giving up');
              markFailed();
              return;
            }

            console.log('[Push][iOS] ✓ FCM token:', fcmToken.substring(0, 20) + '…', 'length:', fcmToken.length);
            await handleValidToken(fcmToken);
          } else {
            if (!isValidFcmToken(rawToken, 'android')) {
              console.warn('[Push][Android] Token failed validation — ignoring');
              return;
            }
            await handleValidToken(rawToken);
          }
        } catch (err) {
          console.error(`[Push][${platform}] registration listener exception:`, err);
        }
      });
      cleanups.push(() => { registrationListener.then(l => l.remove()).catch(() => {}); });

      const registrationErrorListener = PN.addListener('registrationError', (error) => {
        try {
          console.error(`[Push][${platform}] registrationError:`, JSON.stringify(error));
          lastErrorRef.current = error;
          markFailed();
        } catch (err) {
          console.error(`[Push][${platform}] registrationError listener exception:`, err);
        }
      });
      cleanups.push(() => { registrationErrorListener.then(l => l.remove()).catch(() => {}); });

      const fgListener = PN.addListener('pushNotificationReceived', (notification) => {
        try {
          console.log(`[Push][${platform}] Foreground notification received:`, JSON.stringify(notification));
          const data = notification.data as Record<string, string> | undefined;
          handleForegroundNotification(notification.title || '', notification.body || '', data);
        } catch (err) {
          console.error(`[Push][${platform}] pushNotificationReceived listener exception:`, err);
        }
      });
      cleanups.push(() => { fgListener.then(l => l.remove()).catch(() => {}); });

      const actionListener = PN.addListener('pushNotificationActionPerformed', (notification) => {
        try {
          console.log(`[Push][${platform}] Action performed:`, JSON.stringify(notification));
          const data = notification.notification.data as Record<string, string> | undefined;
          handleNotificationAction(data);
        } catch (err) {
          console.error(`[Push][${platform}] pushNotificationActionPerformed listener exception:`, err);
        }
      });
      cleanups.push(() => { actionListener.then(l => l.remove()).catch(() => {}); });

      console.log(`[Push][${platform}] ✓ All 4 listeners registered`);
      resolveListenersReady!();
    })();

    if (platform === 'ios') {
      (async () => {
        try {
          const fcm = await getFcmPlugin();
          if (fcm && typeof (fcm as any).addListener === 'function') {
            console.log('[Push][iOS] FCM plugin ready for token conversion');
          }
        } catch (err) {
          console.warn('[Push][iOS] FCM plugin setup note:', err);
        }
      })();
    }

    let appListenerCleanup: (() => void) | undefined;

    (async () => {
      try {
        const { App } = await import('@capacitor/app');
        const listener = await App.addListener('appStateChange', async ({ isActive }) => {
          try {
            if (!isActive) return;

            const state = registrationStateRef.current;
            console.log(`[Push] App resumed — regState: ${state}, token: ${tokenRef.current ? 'yes' : 'null'}, user: ${userRef.current?.id ?? 'null'}`);

            if (state === 'registered') return;

            const PN = await getPushNotificationsPlugin();
            let resumePermission = 'prompt';
            if (PN) {
              const p = await PN.checkPermissions();
              resumePermission = p.receive;
            }
            console.log(`[Push] Resume permission check: ${resumePermission}`);

            if (resumePermission === 'granted' && userRef.current) {
              setPermissionStatus('granted');
              registrationStateRef.current = 'idle';
              retryCountRef.current = 0;
              console.log('[Push] Permission granted on resume — attempting registration');
              attemptRegistration();
            } else if (resumePermission === 'denied') {
              setPermissionStatus('denied');
            }
          } catch (err) {
            console.error('[Push] appStateChange listener exception:', err);
          }
        });
        appListenerCleanup = () => listener.remove();
      } catch (err) {
        console.error('[Push] Failed to register appStateChange listener:', err);
      }
    })();

    if (user) {
      setTimeout(async () => {
        const stage = await getPushStage();
        console.log(`[Push] Push stage on login: ${stage}`);

        if (stage === 'full') {
          const PN = await getPushNotificationsPlugin();
          let loginPerm = 'prompt';
          if (PN) {
            const p = await PN.checkPermissions();
            loginPerm = p.receive;
          }
          if (loginPerm === 'granted') {
            console.log('[Push] Stage full + permission granted — silent re-registration');
            registrationStateRef.current = 'idle';
            retryCountRef.current = 0;
            attemptRegistration();
          } else {
            console.log(`[Push] Stage full but permission ${loginPerm} — waiting for user action`);
            setPermissionStatus(loginPerm === 'denied' ? 'denied' : 'prompt');
          }
        } else if (stage === 'none' || stage === 'deferred') {
          console.log('[Push] First login — auto-requesting notification permission');
          await setPushStage('full');
          registrationStateRef.current = 'idle';
          retryCountRef.current = 0;
          await attemptRegistration();
        }
      }, 500);
    }

    return () => {
      clearWatchdog();
      cleanups.forEach(fn => fn());
      appListenerCleanup?.();
    };
  }, [user, attemptRegistration, handleValidToken, handleForegroundNotification, handleNotificationAction, navigate, clearWatchdog, markFailed]);

  useEffect(() => {
    if (user && token) {
      console.log('[Push] User now available — retrying token save');
      saveTokenToDatabase(token);
    }
  }, [user, token, saveTokenToDatabase]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      try {
        const { data, error } = await supabase
          .from('device_tokens')
          .select('id, token, platform, updated_at')
          .eq('user_id', user.id);
        if (error) {
          console.error('[Push][Diag] Error querying device_tokens:', error.message);
        } else {
          console.log(`[Push][Diag] User ${user.id} has ${data?.length || 0} registered token(s)`, data);
        }
      } catch (e) {
        console.error('[Push][Diag] Exception:', e);
      }
    })();
  }, [user]);

  const requestFullPermission = useCallback(async () => {
    console.log('[Push] ▶▶▶ requestFullPermission called — upgrading to full stage');

    if (!Capacitor.isNativePlatform()) {
      console.log('[Push] Not native — skipping');
      return;
    }

    const platform = Capacitor.getPlatform();

    const timeout = new Promise<void>((_, reject) =>
      setTimeout(() => reject(new Error('requestFullPermission timed out after 20s')), 20000)
    );

    const doRegister = async () => {
      const PN = await getPushNotificationsPlugin();
      if (!PN) {
        console.error('[Push] ✗ PushNotifications plugin not available');
        setPermissionStatus('denied');
        return;
      }

      let permStatus = await PN.checkPermissions();
      console.log(`[Push] requestFullPermission (${platform}) BEFORE checkPermissions:`, permStatus.receive);

      if (permStatus.receive === 'prompt') {
        console.log(`[Push] requestFullPermission (${platform}) ▶ Calling requestPermissions() NOW — OS prompt should appear`);
        permStatus = await PN.requestPermissions();
        console.log(`[Push] requestFullPermission (${platform}) AFTER requestPermissions:`, permStatus.receive);
      }

      const recheck = await PN.checkPermissions();
      console.log(`[Push] requestFullPermission (${platform}) RE-CHECK:`, recheck.receive);

      const finalStatus = recheck.receive;

      if (finalStatus !== 'granted') {
        const isDenied = finalStatus === 'denied';
        setPermissionStatus(isDenied ? 'denied' : 'prompt');
        console.log(`[Push] ✗ Permission not granted after request. Final: ${finalStatus}`);

        if (!isDenied) {
          console.error('[Push] ✗✗✗ CRITICAL: Permission still "prompt" after requestPermissions() — OS prompt likely suppressed');
        }
        return;
      }

      setPermissionStatus('granted');
      await setPushStage('full');
      console.log(`[Push] ✓ Permission granted — triggering register()`);

      registrationStateRef.current = 'idle';
      retryCountRef.current = 0;
      await attemptRegistration();
    };

    try {
      await Promise.race([doRegister(), timeout]);
    } catch (err) {
      console.error('[Push] requestFullPermission error/timeout:', err);
      registrationStateRef.current = 'idle';
      try {
        const PN = await getPushNotificationsPlugin();
        if (PN) {
          const p = await PN.checkPermissions();
          console.log(`[Push] Post-timeout permission check:`, p.receive);
          if (p.receive === 'granted') {
            setPermissionStatus('granted');
          } else if (p.receive === 'denied') {
            setPermissionStatus('denied');
          }
        }
      } catch {}
    }
  }, [attemptRegistration]);

  return {
    token,
    permissionStatus,
    registerPushNotifications: attemptRegistration,
    requestFullPermission,
    removeTokenFromDatabase,
  };
}
