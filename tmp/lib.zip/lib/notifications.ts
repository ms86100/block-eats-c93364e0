import { supabase } from '@/integrations/supabase/client';
import { OrderStatus } from '@/types/database';
import {
  ORDER_NOTIF_TITLES_BUYER,
  ORDER_NOTIF_TITLES_SELLER,
} from './order-notification-titles';

interface NotificationPayload {
  userId: string;
  title: string;
  body: string;
  data?: Record<string, string>;
}

export async function sendPushNotification(
  payload: NotificationPayload,
  maxRetries = 2
): Promise<boolean> {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const { data, error } = await supabase.functions.invoke(
        'send-push-notification',
        { body: payload }
      );

      if (error) {
        console.error(
          `[Push] Send failed (attempt ${attempt + 1}/${maxRetries + 1}):`,
          error
        );
        if (attempt < maxRetries) {
          await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
          continue;
        }
        return false;
      }

      console.log('[Push] Notification sent:', data);
      return (data?.sent ?? 0) > 0;
    } catch (err) {
      console.error(
        `[Push] Send error (attempt ${attempt + 1}/${maxRetries + 1}):`,
        err
      );
      if (attempt < maxRetries) {
        await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
        continue;
      }
      return false;
    }
  }
  return false;
}

const BUYER_BODIES: Record<string, (sellerName: string) => string> = {
  accepted: (s) => `${s} accepted your order and will start preparing it.`,
  preparing: (s) => `${s} is now preparing your order.`,
  ready: (s) => `Your order from ${s} is ready for pickup!`,
  picked_up: (s) => `Your order from ${s} has been picked up.`,
  on_the_way: (s) => `Your order from ${s} is on the way!`,
  arrived: (s) => `The service provider from ${s} has arrived.`,
  assigned: (s) => `A partner has been assigned for your order from ${s}.`,
  delivered: (s) => `Your order from ${s} has been delivered!`,
  completed: (s) => `Your order from ${s} is complete. Leave a review!`,
  cancelled: (s) => `Your order from ${s} was cancelled.`,
  quoted: (s) => `${s} sent you a price quote for your enquiry.`,
  scheduled: (s) => `${s} confirmed your booking.`,
  in_progress: (s) => `Your service from ${s} is in progress.`,
};

const SELLER_BODIES: Record<string, (buyerName: string, shortId: string) => string> = {
  placed: (b) => `${b} placed an order. Tap to view and accept.`,
  enquired: (b) => `${b} sent a booking request. Tap to view details.`,
  cancelled: (b, id) => `Order #${id} from ${b} was cancelled.`,
};

function getOrderNotificationContent(
  status: OrderStatus,
  sellerName: string,
  buyerName: string,
  orderId: string,
  isForSeller: boolean
): { title: string; body: string } | null {
  const shortOrderId = orderId.slice(0, 8);

  if (isForSeller) {
    const title = ORDER_NOTIF_TITLES_SELLER[status];
    const bodyFn = SELLER_BODIES[status];
    if (!title || !bodyFn) return null;
    return { title, body: bodyFn(buyerName, shortOrderId) };
  } else {
    const title = ORDER_NOTIF_TITLES_BUYER[status];
    const bodyFn = BUYER_BODIES[status];
    if (!title || !bodyFn) return null;
    return { title, body: bodyFn(sellerName) };
  }
}

export async function sendOrderStatusNotification(
  orderId: string,
  newStatus: OrderStatus,
  buyerId: string,
  sellerId: string,
  sellerUserId: string,
  sellerName: string,
  buyerName: string
): Promise<void> {
  const sellerNotification = getOrderNotificationContent(
    newStatus, sellerName, buyerName, orderId, true
  );
  const buyerNotification = getOrderNotificationContent(
    newStatus, sellerName, buyerName, orderId, false
  );

  const notificationData = { orderId, type: 'order', status: newStatus };

  if (sellerNotification) {
    await sendPushNotification({
      userId: sellerUserId,
      title: sellerNotification.title,
      body: sellerNotification.body,
      data: notificationData,
    });
  }

  if (buyerNotification) {
    await sendPushNotification({
      userId: buyerId,
      title: buyerNotification.title,
      body: buyerNotification.body,
      data: notificationData,
    });
  }
}

export async function sendChatNotification(
  recipientId: string,
  senderName: string,
  orderId: string,
  messagePreview: string
): Promise<void> {
  const truncatedMessage =
    messagePreview.length > 50
      ? messagePreview.substring(0, 50) + '...'
      : messagePreview;

  await sendPushNotification({
    userId: recipientId,
    title: `Message from ${senderName}`,
    body: truncatedMessage,
    data: { orderId, type: 'chat' },
  });
}
