import { Capacitor } from '@capacitor/core';
import { supabase } from '@/integrations/supabase/client';

interface DiagnosticResult {
  step: string;
  status: 'pass' | 'fail' | 'skip' | 'warn';
  detail: string;
}

export async function runPushDiagnostics(userId?: string): Promise<DiagnosticResult[]> {
  const results: DiagnosticResult[] = [];
  const platform = Capacitor.getPlatform();

  results.push({
    step: '1. Platform',
    status: Capacitor.isNativePlatform() ? 'pass' : 'warn',
    detail: `Platform: ${platform}, isNative: ${Capacitor.isNativePlatform()}`,
  });

  if (!Capacitor.isNativePlatform()) {
    results.push({
      step: '2-7',
      status: 'skip',
      detail: 'Skipping native checks — not running on iOS/Android',
    });
    return results;
  }

  let PN: any = null;
  try {
    const mod = await import('@capacitor/push-notifications');
    PN = mod.PushNotifications;
    results.push({
      step: '2. PushNotifications plugin',
      status: 'pass',
      detail: 'Plugin loaded successfully',
    });
  } catch (e) {
    results.push({
      step: '2. PushNotifications plugin',
      status: 'fail',
      detail: `FAILED to load: ${e}`,
    });
    return results;
  }

  try {
    const permResult = await PN.checkPermissions();
    const perm = permResult.receive;
    results.push({
      step: '3. Permission status',
      status: perm === 'granted' ? 'pass' : 'fail',
      detail: `Permission: ${perm}${perm === 'prompt' ? ' — user has never been prompted' : perm === 'denied' ? ' — user denied or prompt was suppressed' : ''}`,
    });
  } catch (e) {
    results.push({
      step: '3. Permission status',
      status: 'fail',
      detail: `checkPermissions() threw: ${e}`,
    });
  }

  if (platform === 'ios') {
    try {
      const { FCM } = await import('@capacitor-community/fcm');
      results.push({
        step: '4. FCM plugin (iOS)',
        status: 'pass',
        detail: 'Plugin loaded successfully',
      });

      try {
        const fcmResult = await FCM.getToken();
        const tok = fcmResult?.token;
        if (tok && typeof tok === 'string' && tok.length > 20) {
          const isRawApns = /^[A-Fa-f0-9]{64}$/.test(tok);
          results.push({
            step: '5. FCM token (iOS)',
            status: isRawApns ? 'fail' : 'pass',
            detail: isRawApns
              ? `Got raw APNs token (64 hex chars) instead of FCM token — Firebase may not be configured correctly`
              : `FCM token: ${tok.substring(0, 30)}… (length: ${tok.length})`,
          });
        } else {
          results.push({
            step: '5. FCM token (iOS)',
            status: 'fail',
            detail: `FCM.getToken() returned invalid: ${JSON.stringify(fcmResult)}`,
          });
        }
      } catch (e) {
        results.push({
          step: '5. FCM token (iOS)',
          status: 'fail',
          detail: `FCM.getToken() threw: ${e} — This usually means Firebase is not initialized, GoogleService-Info.plist is missing, or APNs key is not uploaded to Firebase Console`,
        });
      }
    } catch (e) {
      results.push({
        step: '4. FCM plugin (iOS)',
        status: 'fail',
        detail: `FAILED to load @capacitor-community/fcm: ${e}`,
      });
    }
  } else {
    results.push({
      step: '4. FCM plugin',
      status: 'skip',
      detail: 'Android does not need FCM plugin for token conversion',
    });
  }

  if (userId) {
    try {
      const { data, error } = await supabase
        .from('device_tokens')
        .select('id, token, platform, updated_at')
        .eq('user_id', userId);

      if (error) {
        results.push({
          step: '6. device_tokens table',
          status: 'fail',
          detail: `Query failed: ${error.message} (code: ${error.code}) — Check RLS policies allow SELECT for authenticated users`,
        });
      } else if (!data || data.length === 0) {
        results.push({
          step: '6. device_tokens table',
          status: 'fail',
          detail: 'No tokens found for this user — the registration flow never completed successfully',
        });
      } else {
        results.push({
          step: '6. device_tokens table',
          status: 'pass',
          detail: `Found ${data.length} token(s): ${data.map(d => `${d.platform} (updated: ${d.updated_at})`).join(', ')}`,
        });
      }
    } catch (e) {
      results.push({
        step: '6. device_tokens table',
        status: 'fail',
        detail: `Exception: ${e}`,
      });
    }

    try {
      const { data, error } = await supabase.functions.invoke('send-push-notification', {
        body: {
          userId,
          title: 'Push Notification Test',
          body: 'If you see this, push notifications are working!',
          data: { type: 'test' },
        },
      });

      if (error) {
        results.push({
          step: '7. Edge function test',
          status: 'fail',
          detail: `Edge function error: ${error.message ?? JSON.stringify(error)}`,
        });
      } else {
        const sent = data?.sent ?? 0;
        results.push({
          step: '7. Edge function test',
          status: sent > 0 ? 'pass' : 'warn',
          detail: sent > 0
            ? `Test notification sent to ${sent} device(s) — check your phone!`
            : `Edge function returned sent: ${sent} — it found no tokens to send to, or FCM rejected them. Full response: ${JSON.stringify(data)}`,
        });
      }
    } catch (e) {
      results.push({
        step: '7. Edge function test',
        status: 'fail',
        detail: `Edge function exception: ${e}`,
      });
    }
  } else {
    results.push({
      step: '6-7',
      status: 'skip',
      detail: 'No userId provided — skipping database and edge function checks',
    });
  }

  return results;
}

export function printDiagnostics(results: DiagnosticResult[]): void {
  console.log('\n╔══════════════════════════════════════════════════╗');
  console.log('║       PUSH NOTIFICATION DIAGNOSTIC REPORT       ║');
  console.log('╚══════════════════════════════════════════════════╝\n');

  for (const r of results) {
    const icon = r.status === 'pass' ? '✅' : r.status === 'fail' ? '❌' : r.status === 'warn' ? '⚠️' : '⏭️';
    console.log(`${icon} ${r.step}`);
    console.log(`   ${r.detail}\n`);
  }

  const failed = results.filter(r => r.status === 'fail');
  if (failed.length === 0) {
    console.log('✅ All checks passed — push notifications should be working.');
  } else {
    console.log(`❌ ${failed.length} check(s) failed. Fix the first failure — later ones are often caused by earlier ones.\n`);
    console.log('FIRST FAILURE:', failed[0].step);
    console.log('DETAIL:', failed[0].detail);
  }
}
