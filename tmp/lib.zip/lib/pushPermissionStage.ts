import { Capacitor } from '@capacitor/core';

export type PushStage = 'none' | 'deferred' | 'full';

const KEY = 'push_permission_stage';

async function getPreferences() {
  const { Preferences } = await import('@capacitor/preferences');
  return Preferences;
}

export async function getPushStage(): Promise<PushStage> {
  if (!Capacitor.isNativePlatform()) return 'none';
  try {
    const Preferences = await getPreferences();
    const { value } = await Preferences.get({ key: KEY });
    if (value === 'deferred' || value === 'full') return value;
    return 'none';
  } catch {
    return 'none';
  }
}

export async function setPushStage(stage: PushStage): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;
  try {
    const Preferences = await getPreferences();
    await Preferences.set({ key: KEY, value: stage });
  } catch (e) {
    console.warn('[PushStage] Failed to save stage:', e);
  }
}
